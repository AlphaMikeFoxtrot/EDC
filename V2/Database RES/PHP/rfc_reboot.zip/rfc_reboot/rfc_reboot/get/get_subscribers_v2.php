<?php

    require "connection.php";
    
    /*
    
        CODE FORMAT:
            100 --> book only       (RFC)
            200 --> toy only        (ETL)
            300 --> book and toy    (RFC + ETL)
        
    */
    
    $code = "100"; // $_POST['code'];
    
    switch($code){
        
        case 100:
            // book only
            
            break;
        
        case 200:
            // toy only
            
            break;
        
        case 300:
            // book and toy
            
            break;
        
    }

?>