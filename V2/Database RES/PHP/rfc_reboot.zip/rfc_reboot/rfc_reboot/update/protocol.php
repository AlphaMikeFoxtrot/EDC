<?php

    require "connection.php";
    
    $protocol = $_POST["protocol"]; // "issue";
    $type = $_POST["type"]; // "book";
    $id = $_POST["id"]; // "SB-45";
    $sub = $_POST["sub"]; // "SB/Lib/9472";

    if($protocol == "issue"){

        if($type == "book"){
            
            $query_get_name = "SELECT `subscribers`.`subscriber_name` FROM `subscribers` WHERE `subscribers`.`subscriber_id`='$sub';";
            
            $response_get_name = mysqli_query($connection, $query_get_name);
            
            $row = mysqli_fetch_assoc($response_get_name);
            
            $sub_name = $row['subscriber_name'];
            
            $query_update_books = "UPDATE `books` SET `books`.`is_issued`=1, `books`.`issued_to_id`='$sub', `books`.`issued_to_name`='$sub' WHERE `books`.`book_id`='$id';";
            $query_update_subscriber = "UPDATE `subscribers` SET `subscribers`.`book_issued`='1' WHERE `subscribers`.`subscriber_id`='$sub';";
            $date = date('d-M-Y');
            $query_update_log = "INSERT INTO `log`(`log`.`subscriber_id`, `log`.`book_id`, `log`.`date`) VALUES('$sub', '$id', '$date');";
            
            if(mysqli_query($connection, $query_update_books) && mysqli_query($connection, $query_update_subscriber) && mysqli_query($connection, $query_update_log)){
                echo "success";
            } else {
                echo "fail" . mysqli_error($connection);
            }
            
        } else if($type == "toy"){
            
            $query_get_name = "SELECT `subscribers`.`subscriber_name` FROM `subscribers` WHERE `subscribers`.`subscriber_id`='$sub';";
            
            $response_get_name = mysqli_query($connection, $query_get_name);
            
            $row = mysqli_fetch_assoc($response_get_name);
            
            $sub_name = $row['subscriber_name'];
            
            $query_update_books = "UPDATE `toys` SET `toys`.`is_issued`=1, `toys`.`issued_to_id`='$sub', `toys`.`issued_to_name`='$sub' WHERE `toys`.`toy_id`='$id';";
            $query_update_subscriber = "UPDATE `subscribers` SET `subscribers`.`toy_issued`='1' WHERE `subscribers`.`subscriber_id`='$sub';";
            $date = date('M');
            $query_update_log = "INSERT INTO `log`(`log`.`subscriber_id`, `log`.`toy_id`, `log`.`date`) VALUES('$sub', '$id', '$date');";
            
            if(mysqli_query($connection, $query_update_books) && mysqli_query($connection, $query_update_subscriber) && mysqli_query($connection, $query_update_log)){
                echo "success";
            } else {
                echo "fail" . mysqli_error($connection);
            }
            
        } else {
            echo "wrong type - " . $type;
        }
        
    } else if($protocol == "return") {
        
        if($type == "book"){
        
            $query_update_books = "UPDATE `books` SET `books`.`is_issued`=0, `books`.`issued_to_id`='NULL', `books`.`issued_to_name`='NULL' WHERE `books`.`book_id`='$id';";
            $query_update_subscriber = "UPDATE `subscribers` SET `subscribers`.`book_issued`='0' WHERE `subscribers`.`subscriber_id`='$sub';";
            
            $date = date('d-M-Y');
            $query_update_return_log = "INSERT INTO `return_log` VALUES('$type', '$id', '$sub', '$date');";
            
            if(mysqli_query($connection, $query_update_books) && mysqli_query($connection, $query_update_subscriber) && mysqli_query($connection, $query_update_return_log)){
                echo "success";
            } else {
                echo "fail" . mysqli_error($connection);
            }
        
        } else if($type == "toy"){
            
            $query_update_books = "UPDATE `toys` SET `toys`.`is_issued`=0, `toys`.`issued_to_id`='NULL', `toys`.`issued_to_name`='NULL' WHERE `toys`.`toy_id`='$id';";
            $query_update_subscriber = "UPDATE `subscribers` SET `subscribers`.`toy_issued`='0' WHERE `subscribers`.`subscriber_id`='$sub';";
            
            $date = date('d-M-Y');
            $query_update_return_log = "INSERT INTO `return_log` VALUES('$type', '$id', '$sub', '$date');";
            
            if(mysqli_query($connection, $query_update_books) && mysqli_query($connection, $query_update_subscriber) && mysqli_query($connection, $query_update_return_log)){
                echo "success";
            } else {
                echo "fail" . mysqli_error($connection);
            }
            
        }
        
    }
        
?>